# VOIDCROWN Ω TOTAL 25.0.0

Abre index.html.

- VOID SMASH: capas, armas, población, cicatrices, EDAI
- SISTEMA: gravedad N-cuerpos
- DRIVE / CANON / EDAI tabs

APK existente: 02_BETA_JUGABLE/VOIDCROWN_24.1.1_ABSORB_WS105_SIGNED.apk
